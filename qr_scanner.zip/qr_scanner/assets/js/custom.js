
$(".zoomImageIn").click(function(){
	
	var imageUrl = $(this).find("img").attr("src");
	
	$("#modalImage").attr("src", imageUrl);
	$("#imageShow").modal("show");
	
});	

$('.datepicker').datepicker({
	format: "yyyy-mm-dd"
});

function prepare(){
	var path = window.location.pathname;
	var pathCount = (path.match(new RegExp("/", "g")) || []).length;
	var linkPlus = "";
	for(var i = 1; i < pathCount; i++)
		linkPlus += "../";
	
	return "";//linkPlus;
}

$(document).ready(function(){
	$("#send").click(function(){

		$(this).prop('disabled', true);

		var formData = $('form#sendForm').serialize();

		$.ajax({
			
			type: "POST",
			url: prepare() + "siteEngine/plugins/getRequest?lang=AR",
			data: formData,
			success: function(msg){
				
				$("#message").html(msg);
				$("#send").prop('disabled', false);
				
			},error: function(){
				
				$("#message").html("<div class='alert alert-danger text-right'>من فضلك تاكد من ان جهاز الحاسب متصل بالانترنت</div>");
				$("#send").prop('disabled', false);
				
			}
		
	   });
	   
	});
	
	$("#send-x").click(function(){

		$(this).prop('disabled', true);

		var formData = $('form#sendForm-x').serialize();

		$.ajax({
			
			type: "POST",
			url: prepare() + "siteEngine/plugins/getRequest?lang=AR",
			data: formData,
			success: function(msg){
				
				$("#message-x").html(msg);
				$("#send-x").prop('disabled', false);
				
			},error: function(){
				
				$("#message-x").html("<div class='error-message'>من فضلك تاكد من ان جهاز الحاسب متصل بالانترنت</div>");
				$("#send-x").prop('disabled', false);
				
			}
		
	   });
	   
	});
});

$("#order-ar").click(function(){

	$(this).prop('disabled', true);
	
	var formData = $('form#orderForm').serialize();
	
	$.ajax({
		
		type: "POST",
		url: "../../siteEngine/plugins/getRegist?lang=AR",
		data: formData,
		success: function(msg){
			
			$("#message_plus").html(msg);
			$("#order-ar").prop('disabled', false);
			
		},error: function(){
			
			$("#message_plus").html("<div class='error-message'>خطأ : من فضلك تاكد من ان جهاز الحاسب متصل بالانترنت</div>");
			$("#order-ar").prop('disabled', false);
			
		}
	
   });
   
});
$(document).ready(function(){

	if(!($("#products-menu").length)) return;
	
	var page = 0;
	var defaultPage = $("#products-menu").attr('default-category');
	
	reload();
	
	$(".products-tab").click(function(){
		
		$("#products-menu").html("<img src='" + prepare() + "assets/images/32.gif" + "' style='width: 50%; margin: 20px auto;'>");
		
		if(defaultPage != $(this).attr('cat-id')){
			defaultPage = $(this).attr('cat-id');
			$("#products-menu").attr('default-category', defaultPage);
		}
		
		$(".products-tab").removeClass("active");
		$(this).addClass("active");
		
		page = 0;
		
		reload();
		
	});
	
	function reload(){
		
		$.ajax({
			
			type: "POST",
			url: prepare() + "siteEngine/plugins/productsByCategory",
			data: {
				"cat" : defaultPage,
				"startFrom" : page
			},
			success: function(msg){
				$("#products-menu").html(msg);
				pagination();
			},error: function(){
				$("#products-menu").html("<div class='error-message'>من فضلك تاكد من ان جهاز الحاسب متصل بالانترنت</div>");
			}
		
	   });
	   
	}
	
	function pagination(){
		$(".goto-page").click(function(){
			$("#products-menu").html("<img src='" + prepare() + "assets/images/32.gif" + "' style='width: 50%; margin: 20px auto;'>");
			page = ($(this).attr('get-page') - 1) * 9;
			reload();
		});
	}
	
});


$(document).ready(function() {

	$(".open-img-modal").click(function () {
		let image = $(this).find("img").attr("src");
		if(!$(".image-modal").length) {
			let modal = '<div class="modal fade image-modal" role="dialog">' +
				'<div class="modal-dialog">' +
				'<div class="modal-content">' +
				'<div class="modal-body">' +
				'<button type="button" class="close" data-dismiss="modal">&times;</button>' +
				'<img src="assets/images/logo.png" width="100%" class="large-modal-image"> ' +
				'</div>' +
				'</div>' +
				'</div>';
			$("body").append(modal);
		}
		$(".large-modal-image").attr("src", image);
		$(".image-modal").modal("show");
	});
	
});

$(document).ready(function(){

	if(!($("#all-products").length)) return;
	
	var page = 0;
	var defaultPage = $("#product-cat").val();
	var priceStart  = $("#s_price").val();
	var priceEnd    = $("#e_price").val();
	
	reload();
	
	$("#filter").click(function(){
		
		defaultPage = $("#product-cat").val();
		priceStart  = $("#s_price").val();
		priceEnd    = $("#e_price").val();
		
		page = 0;
		
		reload();
		
	});
	
	function reload(){
		
		$.ajax({
			
			type: "POST",
			url: prepare() + "siteEngine/plugins/products",
			data: {
				"cat" : defaultPage,
				"priceStart" : priceStart,
				"priceEnd" : priceEnd,
				"startFrom" : page
			},
			success: function(msg){
				$("#all-products").html(msg);
				pagination();
			},error: function(){
				$("#all-products").html("<div class='error-message'>من فضلك تاكد من ان جهاز الحاسب متصل بالانترنت</div>");
			}
		
	   });
	   
	}
	
	function pagination(){
		$(".goto-page").click(function(){
			$("#all-products").html("<img src='" + prepare() + "assets/images/32.gif" + "' style='width: 50%; margin: 20px auto;'>");
			page = ($(this).attr('get-page') - 1) * 9;
			reload();
		});
	}
	
});

$(document).ready(function(){

	if(!($("#search-products").length)) return;
	
	var page = 0;
	var search = $("#searchV").val();
	
	reload();
	
	$("#filter").click(function(){
		
		search = $("#searchV").val();
		
		page = 0;
		
		reload();
		
	});
	
	function reload(){
		
		$.ajax({
			
			type: "POST",
			url: prepare() + "siteEngine/plugins/productsSearch",
			data: {
				"key" : search,
				"startFrom" : page
			},
			success: function(msg){
				$("#search-products").html(msg);
				pagination();
			},error: function(){
				$("#search-products").html("<div class='error-message'>من فضلك تاكد من ان جهاز الحاسب متصل بالانترنت</div>");
			}
		
	   });
	   
	}
	
	function pagination(){
		$(".goto-page").click(function(){
			$("#search-products").html("<img src='" + prepare() + "assets/images/32.gif" + "' style='width: 50%; margin: 20px auto;'>");
			page = ($(this).attr('get-page') - 1) * 9;
			reload();
		});
	}
	
});
