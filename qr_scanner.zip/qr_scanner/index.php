<?php
require_once ("lib/loader.php");
if(isSignedIn("admin")) redirect("admin");
if(isSignedIn("doctor")) redirect("doctor");
if(isSignedIn("student")) redirect("student");
?>
<!doctype html>
<html class="no-js" lang="en">
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1">

        <title> اكاديمية طيبة العليا </title>
		<!-- animate css -->
        <link rel="stylesheet" href="assets/css/animate.css">
		<!-- jquery-ui.min css -->
        <link rel="stylesheet" href="assets/css/jquery-ui.min.css">
		<!-- meanmenu css -->
        <link rel="stylesheet" href="assets/css/meanmenu.min.css">
		<!-- owl.carousel css -->
        <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
        <!-- magnific popup css -->
        <link rel="stylesheet" href="assets/css/magnific-popup.css">
        <!-- bootstrap v3.3.6 css -->
        <link rel="stylesheet" href="assets/css/bootstrap.min.css">
		<!-- font-awesome css -->
        <link rel="stylesheet" href="assets/css/font-awesome.min.css">
        <!-- fancybox css -->
        <link rel="stylesheet" href="assets/css/jquery.fancybox.css">
        <!-- flaticon css -->
        <link rel="stylesheet" href="assets/css/flaticon.css">
        <!-- slick css -->
        <link rel="stylesheet" href="assets/css/slick.css">

        <link rel="stylesheet" href="assets/css/style.css">
		<!-- style css -->
		<link rel="stylesheet" href="assets/style.css">
		<!-- responsive css -->
        <link rel="stylesheet" href="assets/css/responsive.css">
		<!-- modernizr css -->
        <script src="assets/js/vendor/modernizr-2.8.3.min.js"></script>
		<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
		<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
		<!--[if lt IE 9]>
		  <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
		  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
		<![endif]-->
		
	</head>
    <body>

        <!--Preloader area -->
        <div id="preloader">
            <div id="status" class="spinner">
                <div class="double-bounce1"></div>
                <div class="double-bounce2"></div>
            </div>
        </div>

        <header>
            <div class="topbar">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-6 col-md-6 col-sm-3 col-xs-12 hidden-sm hidden-xs">
                            <div class="top-l-social">
                                <ul class="list-inline">
                                    <li><a href="#"><i class="fa fa-facebook"></i> </a></li>
                                    <li><a href="#"><i class="fa fa-twitter"></i> </a></li>
                                    <li><a href="#"><i class="fa fa-instagram"></i> </a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-6 col-sm-9 col-xs-12">
                            <div class="top-linked text-right">
                                <ul class="list-inline">
                                    <li><a href="#"><i class="fa fa-envelope"></i><span>info@thebes-academy.edu</span></a></li>
                                    <li><a href="#"><i class="fa fa-mobile-phone"></i><span>0222222222222</span></a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="header-middel">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-6 col-md-6 col-sm-7 col-xs-8">
                            <div class="logo">
                                <a href="./"><img class="top-logo" src="assets/images/logo.png" alt="اكاديمية طيبة العليا"/></a>
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-6 col-sm-5 col-xs-4">
                            <div class="cart-btn text-right">
                                <a href="./" class="cart-btns" title="cart">
                                    <strong>تسجيل الدخول</strong>
                                    <span class="icon"><i class="fa fa-sign-in"></i></span>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="main-menu">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <div class="menu-list">
                                <nav>
                                    <ul class="list-inline">
                                        <li class="lists-menus">
                                             <li><a href="./">تسجيل دخول</a></li>
                                        </li>
                                    </ul>
                                </nav>
                            </div>
                            <!-- Mobile Menu  Start -->
                            <div class="mobilemenu1">
                                <div class="mobile-menu visible-sm visible-xs">
                                    <button class="btn btn-menu mobile-menu-alt"><i class="fa fa-bars"></i></button>
                                </div>
                            </div>
                            <!-- Mobile Menu End -->
                        </div>
                    </div>
                </div>
                <div class="cat-ser">
                    <div class="search-box">
                    </div>
                </div>
            </div>
            <!--Offset wrapper end here-->
            <div class="offset-overlay"></div>
            <div class="offset-area">
                <!--Cart area start-->
                <div class="offset-cart-area offset-body">
                    <div class="offset-heading text-right"><h3>القائمة الرئيسية</h3><i class="close-offset flaticon-letter-x"></i></div>
                    <div class="cart-list">
                        <nav class="actions-nav">
                            <ul class="actions-list">
                                <li><a href="">تسجيل دخول</a></li>
                            </ul>
                        </nav>
                    </div>
                </div>
                <!--Cart area end-->
            </div>
        </header>
        <section class="contatc-us section">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12 col-sm-12 pd-0">
                        <div class="contact-form ar">
                            <h2 class="text-right">تسجيل الدخول</h2>
                            <form method="post" action="">
                                <div id="message-x">
                                    <?php
                                    if(set("send")) signIn(post("email"), post("password"));
                                    ?>
                                </div>
                                <div class="col-sm-6 pd-l0">
                                    <fieldset><input type="text" class="text-right" name="email" placeholder="الكود"></fieldset>
                                </div>
                                <div class="col-sm-6 pd-l0">
                                    <fieldset><input type="password" class="text-right" name="password" placeholder="كلمة السر"></fieldset>
                                </div>
                                <button class="btn1" type="submit" name="send">دخول</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- jquery latest version -->
        <script src="assets/js/vendor/jquery-3.2.1.min.js"></script>
		<!-- tether js -->
		<script src="assets/js/tether.min.js"></script>
		<!-- bootstrap js -->
        <script src="assets/js/bootstrap.min.js"></script>
        <!-- owl.carousel js -->
        <script src="assets/js/owl.carousel.min.js"></script>
        <!-- magnific popup js -->
        <script src="assets/js/jquery.magnific-popup.min.js"></script>
		<!-- meanmenu js -->
        <script src="assets/js/jquery.meanmenu.js"></script>
        <!-- jarallax js -->
        <script src="assets/js/jarallax.min.js"></script>
		<!-- jquery-ui js -->
        <script src="assets/js/jquery-ui.min.js"></script>
        <!-- downCount JS -->
        <script src="assets/js/jquery.downCount.js"></script>
        <!-- slick js -->
        <script src="assets/js/slick.min.js"></script>
        <!-- touchspin js -->
        <script src="assets/js/jquery.bootstrap-touchspin.min.js"></script>
		<!-- fancybox js -->
        <script src="assets/js/jquery.fancybox.min.js"></script>
        <!-- wow js -->
        <script src="assets/js/wow.min.js"></script>
		<!-- plugins js -->
        <script src="assets/js/plugins.js"></script>
		<!-- main js -->
        <script src="assets/js/main.js"></script>
        <!-- custom js -->
        <script src="assets/js/custom.js"></script>
	</body>
</html>