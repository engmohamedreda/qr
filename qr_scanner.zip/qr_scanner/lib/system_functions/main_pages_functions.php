<?php

$activeUser = null;

function isSignedIn($type){
    global $activeUser;
    switch ($type){
        case "admin":
            $key = get_cookie($type);
            if($key === false){
                return false;
            }
            $query = new MySQLQuery();
            $query->where(["id" => $key["value"]]);
            if(!$query->select("admin")){
                getMessage($query->error());
                return false;
            }
            if($query->rows() != 1){
                unset_cookies("admin");
                return false;
            }
            $activeUser = $query->results()[0];
            break;
        case "doctor":
            $key = get_cookie($type);
            if($key === false){
                return false;
            }
            $query = new MySQLQuery();
            $query->where(["id" => $key["value"]]);
            if(!$query->select("doctor")){
                getMessage($query->error());
                return false;
            }
            if($query->rows() != 1){
                unset_cookies("doctor");
                return false;
            }
            $activeUser = $query->results()[0];
            break;
        case "student":
            $key = get_cookie($type);
            if($key === false){
                return false;
            }
            $query = new MySQLQuery();
            $query->where(["id" => $key["value"]]);
            if(!$query->select("student")){
                getMessage($query->error());
                return false;
            }
            if($query->rows() != 1){
                unset_cookies("student");
                return false;
            }
            $activeUser = $query->results()[0];
            break;
        default:
            return false;
    }

    return true;

}

function signIn($email, $password){

    if(empty($email)){
        getMessage("الكود غير صحيح");
        return false;
    }

    $password = EncodingManager::password($password);

    $where = ["code" => $email, "password" => $password];

    $query = new MySQLQuery();

    $query->where($where);
    if(!$query->select("admin")){
        getMessage($query->error() . $query->sql());
        return false;
    }
    if($query->rows() == 1){
        $result = $query->results()[0];
        set_cookie("admin", $result["id"]);
        redirect("admin/");
        return true;
    }

    $query->where($where);
    if(!$query->select("doctor")){
        getMessage($query->error() . $query->sql());
        return false;
    }
    if($query->rows() == 1){
        $result = $query->results()[0];
        set_cookie("doctor", $result["id"]);
        redirect("doctor/");
        return true;
    }

    $query->where($where);
    if(!$query->select("student")){
        getMessage($query->error());
        return false;
    }
    if($query->rows() == 1){
        $result = $query->results()[0];
        set_cookie("student", $result["id"]);
        redirect("student/");
        return true;
    }

    getMessage("المستخدم غير مسجل");
    return false;

}
