<?php

class Where{

	private $where = null;
	private $whereVals = [];
	
	private $operators  = ['=','>=','<=','>','<','LIKE','<>','IS','IS NOT'];
	private $conditions = ['AND','OR'];

	public static function run($where){
	    return new Where($where);
    }

	public function __construct($where){
		
		$this->where = null;
		$this->whereVals = [];
		
		if(is_array($where)){
			
			if(!count($where)) return;
			
			$keys = array_keys($where);
			$vals = array_values($where);
			
			$this->where = " WHERE ";
			
			for($i = 0; $i < count($where); $i++){
				
				if($i){
					
					$cond = "AND ";
					
					if(is_array($vals[$i-1]) && isset($vals[$i-1][2]) && in_array(strtoupper($vals[$i-1][2]), $this->conditions)){
						$cond = strtoupper($vals[$i-1][2]);
					}else if(is_array($vals[$i-1]) && isset($vals[$i-1][1]) && in_array(strtoupper($vals[$i-1][1]), $this->conditions)){
						$cond = strtoupper($vals[$i-1][1]);
					}
					
					$this->where .= " " . $cond;	
					
				}
				
				if(isset($vals[$i]["vals"]) && is_array($vals[$i]["vals"])){
				
					if(is_array($vals[$i]["vals"][0])){
						
						for($o = 0; $o < count($vals[$i]["vals"]); $o++){
						
							if($o){
								
								$cond = "AND ";
								
								if(is_array($vals[$i]["vals"][$o-1]) && isset($vals[$i]["vals"][$o-1][2]) && in_array(strtoupper($vals[$i]["vals"][$o-1][2]), $this->conditions)){
									$cond = strtoupper($vals[$i]["vals"][$o-1][2]);
								}else if(is_array($vals[$i]["vals"][$o-1]) && isset($vals[$i]["vals"][$o-1][1]) && in_array(strtoupper($vals[$i]["vals"][$o-1][1]), $this->conditions)){
									$cond = strtoupper($vals[$i]["vals"][$o-1][1]);
								}
								
								$this->where .= " " . $cond;	
								
							}
							
							$this->where .= "`" . $keys[$i] . "` ";
							
							if(is_array($vals[$i]["vals"][$o]) && isset($vals[$i]["vals"][$o][0]) && in_array(strtoupper($vals[$i]["vals"][$o][0]), $this->operators)){
								$this->where .= strtoupper($vals[$i]["vals"][$o][0]);
								$this->whereVals[] = $vals[$i]["vals"][$o][1];
							}else{
								$this->where .= "=";
								$this->whereVals[] = $vals[$i]["vals"][$o][0];
							}
							
							$this->where .=  " ? ";
							
						}
						
					}else{
						
						$this->where .= "`" . $keys[$i] . "` IN (";
						
						for($o = 0; $o < count($vals[$i]["vals"]); $o++){
							if($o) $this->where .= ",";
							$this->where .= "?";
							$this->whereVals[] = $vals[$i]["vals"][$o];
						}
						
						$this->where .= ") ";
						
					}
					
				}else{
					
					$this->where .= "`" . $keys[$i] . "` ";
					
					if(is_array($vals[$i]) && isset($vals[$i][0]) && in_array(strtoupper($vals[$i][0]), $this->operators)){
						$this->where .= strtoupper($vals[$i][0]);
						$this->whereVals[] = $vals[$i][1];
					}else{
						$this->where .= "=";
						$this->whereVals[] = is_array($vals[$i]) ? $vals[$i][0] : $vals[$i];
					}
					
					$this->where .=  " ? ";
					
				}
		
			}
			
		}else{
			
			$this->whereVals = [];
			if(empty($where)) return;
			
			$this->where = " WHERE " . $where;
			
		}
		
	}
	
	public function format(){
		return $this->where;
	}
	
	public function values(){
		return $this->whereVals;
	}
	
}