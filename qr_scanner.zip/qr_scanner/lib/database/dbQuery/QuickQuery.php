<?php

abstract class QuickQuery extends Query{

    protected $where;

    public abstract function version();

    public abstract function tables();

    public abstract function createTable($table, $colsArray = []);

    public abstract function tableExists($table);

    public abstract function removeTable($table);

    public abstract function addColumns($table,$colsArray);

    public abstract function showColumns($table);

    public abstract function removeColumn($table,$col);

    public abstract function editColumns($table,$col,$name,$type,$length,$isNull);

    public abstract function moveColumn($table,$col,$after = null);

    public abstract function addPrimary($table,$col,$autoIncrement = true);

    public abstract function removePrimary($table);

    public abstract function addIndex($table,$col);

    public abstract function addUnique($table,$col);

    public abstract function indexes($table, $PK = false);

    public abstract function removeIndex($table,$col);

    public abstract function addRelation($table1,$fk,$table2,$pk);

    public abstract function getRelations($table);

    public abstract function removeRelation($table,$constraint);

    public abstract function insert($table,$values);

    public abstract function update($table,$values);

    public abstract function select($table, $cols = [], $orderBy = [], $limit = 0, $startFrom = 0);

    public abstract function delete($table, $limit = 0);

    public abstract function export($createDB = false, $values = true, $table = null);

    public function where($where = null){
        if(empty($where)) return $this->where;
        $this->where = new Where($where);
        return $this->where;
    }

}