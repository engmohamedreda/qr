<?php

abstract class DBSettings{
	
	public static function SupportedDatabases(){
		return  
		[
			"MySQL" => ["SettingsClass" => "MySQLDBSettings", "ConnectionClass" => "MySQLDBConnect"],
			"MSSQL" => ["SettingsClass" => "MSSQLDBSettings", "ConnectionClass" => "MSSQLDBConnect"],
			"SQLITE" => ["SettingsClass" => "SQLITEDBSettings", "ConnectionClass" => "SQLITEDBConnect"]
		];
	}
	
	public static function initialize(){
		if(!isset(self::SupportedDatabases()[DB_TYPE])){
			echo "database settings class is not exists please check your configuration file or reinstall lib";
            return null;
		}
		$class = self::SupportedDatabases()[DB_TYPE]["SettingsClass"];
		return new $class();
	}
	
	public abstract function dataTypes();
	
}