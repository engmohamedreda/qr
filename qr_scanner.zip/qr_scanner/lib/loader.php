<?php

ob_start();
date_default_timezone_set('Africa/Cairo');
if(session_status() == PHP_SESSION_NONE) session_start();

require_once('config.php');

// including database classes
require_once('database/dbConnection/DBConnect.php');
require_once('database/dbConnection/MySQLDBConnect.php');
require_once('database/dbSettings/DBSettings.php');
require_once('database/dbSettings/MySQLDBSettings.php');
require_once('database/dbQuery/Where.php');
require_once('database/dbQuery/Query.php');
require_once('database/dbQuery/QuickQuery.php');
require_once('database/dbQuery/MySQLQuery.php');
// including helpers classes
require_once('helpers/Validation.php');
require_once('helpers/EncodingManager.php');
require_once('helpers/Accessories.php');

// including functions
require_once('functions.php');
require_once('system_functions/main_pages_functions.php');