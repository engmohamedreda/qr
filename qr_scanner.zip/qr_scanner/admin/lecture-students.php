<?php
require_once ("../lib/loader.php");
if(!isSignedIn("admin")){
    redirect("../");
    return;
}

global $activeUser;

$table = "lecture";

$id = get("id");
$query = new MySQLQuery();

$query->where(["id" => $id]);

if(!$query->select($table)){
    redirect("./");
    return;
}
if($query->rows() != 1){
    redirect("./");
    return;
}

$current = $query->results()[0];

$query->where(["id" => $current["subject"]]);
$query->select("subject");
$subject = $query->results()[0];

$query->where(["id" => $current["doctor"]]);
$query->select("doctor");
$doctor = $query->results()[0];

$query->where(["id" => $subject["level"]]);
$query->select("level");
$level = $query->results()[0];

$query->where(["id" => $level["section"]]);
$query->select("section");
$section = $query->results()[0];

$query->sql("SELECT * FROM `student` WHERE `id` IN (SELECT `student` FROM `student_subject` WHERE `subject` = ?)");
$query->value($subject["id"]);
$query->execute();
$students = $query->results();

$query->where(["lecture" => $current["id"]]);
$query->select("student_lecture");
$signed = [];
$data = [];
foreach ($query->results() as $result){
    $signed[] = $result["student"];
    $data[$result["student"]] = ["lat" => $result["lat"], "lng" => $result["lng"]];
}

$signedCount = count($signed);
$studentsCount = count($students);
$unsigned = $studentsCount - $signedCount;

?>
<!doctype html>
<html class="no-js" lang="en">
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1">

        <title> اكاديمية طيبة العليا </title>
		<!-- animate css -->
        <link rel="stylesheet" href="../assets/css/animate.css">
		<!-- jquery-ui.min css -->
        <link rel="stylesheet" href="../assets/css/jquery-ui.min.css">
		<!-- meanmenu css -->
        <link rel="stylesheet" href="../assets/css/meanmenu.min.css">
		<!-- owl.carousel css -->
        <link rel="stylesheet" href="../assets/css/owl.carousel.min.css">
        <!-- magnific popup css -->
        <link rel="stylesheet" href="../assets/css/magnific-popup.css">
        <!-- bootstrap v3.3.6 css -->
        <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
		<!-- font-awesome css -->
        <link rel="stylesheet" href="../assets/css/font-awesome.min.css">
        <!-- fancybox css -->
        <link rel="stylesheet" href="../assets/css/jquery.fancybox.css">
        <!-- flaticon css -->
        <link rel="stylesheet" href="../assets/css/flaticon.css">
        <!-- slick css -->
        <link rel="stylesheet" href="../assets/css/slick.css">

        <link rel="stylesheet" href="../assets/css/style.css">
		<!-- style css -->
		<link rel="stylesheet" href="../assets/style.css">
		<!-- responsive css -->
        <link rel="stylesheet" href="../assets/css/responsive.css">
		<!-- modernizr css -->
        <script src="../assets/js/vendor/modernizr-2.8.3.min.js"></script>
		<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
		<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
		<!--[if lt IE 9]>
		  <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
		  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
		<![endif]-->
		
	</head>
    <body>

        <!--Preloader area -->
        <div id="preloader">
            <div id="status" class="spinner">
                <div class="double-bounce1"></div>
                <div class="double-bounce2"></div>
            </div>
        </div>

        <?php
        include ("header.php");
        ?>

        <section class="trands-product section4">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <a href="lectures.php?id=<?= get("id") ?>" class="btn3"> رجوع </a>
                        <hr>
                    </div>
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <div class="section-heading">
                            <h2>كشف الحضور</h2>
                        </div>
                    </div>
                </div>
                <div class="row wow animated fadeIn" data-wow-duration="1.5s">
                    <div class="col-xs-12">
                        <table class="table table-striped ar">
                            <tr>
                                <th>الكود</th>
                                <th>الاسم</th>
                                <th>الحالة</th>
                                <th>مكان</th>
                            </tr>
                            <?php
                            foreach ($students as $student){
                                $enable = (in_array($student["id"], $signed));
                                ?>
                                <tr>
                                    <th><?= $student["code"] ?></th>
                                    <th><?= $student["name"] ?></th>
                                    <th><?= ($enable ? "<span class='color-green'>حضر</span>" : "<span class='color-red'>غاب</span>") ?></th>
                                    <th>
                                        <?php
                                        if($enable){
                                            ?><a href="javascript:void(0)" class="btn1" onclick="WebSystem.openLocation('doctor/lecture-students.php?id=<?= get("id") ?>',
                                                    '<?= $data[$student["id"]]["lat"] ?>', '<?= $data[$student["id"]]["lng"] ?>', '<?= $student["name"] ?>')"><i class="fa fa-map-pin"></i> </a>
                                            <?php
                                        }
                                        ?>
                                    </th>
                                </tr>
                                <?php
                            }
                            ?>
                        </table>
                        <hr>
                        <table class="table table-bordered ar">
                            <tr>
                                <th>الطلاب المسجلين</th>
                                <th>الحاضرين</th>
                                <th>الغائبين</th>
                            </tr>
                            <tr>
                                <th><?= $studentsCount ?></th>
                                <th><?= $signedCount ?></th>
                                <th><?= $unsigned ?></th>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
        </section>
        <!-- jquery latest version -->
        <script src="../assets/js/vendor/jquery-3.2.1.min.js"></script>
		<!-- tether js -->
		<script src="../assets/js/tether.min.js"></script>
		<!-- bootstrap js -->
        <script src="../assets/js/bootstrap.min.js"></script>
        <!-- owl.carousel js -->
        <script src="../assets/js/owl.carousel.min.js"></script>
        <!-- magnific popup js -->
        <script src="../assets/js/jquery.magnific-popup.min.js"></script>
		<!-- meanmenu js -->
        <script src="../assets/js/jquery.meanmenu.js"></script>
        <!-- jarallax js -->
        <script src="../assets/js/jarallax.min.js"></script>
		<!-- jquery-ui js -->
        <script src="../assets/js/jquery-ui.min.js"></script>
        <!-- downCount JS -->
        <script src="../assets/js/jquery.downCount.js"></script>
        <!-- slick js -->
        <script src="../assets/js/slick.min.js"></script>
        <!-- touchspin js -->
        <script src="../assets/js/jquery.bootstrap-touchspin.min.js"></script>
		<!-- fancybox js -->
        <script src="../assets/js/jquery.fancybox.min.js"></script>
        <!-- wow js -->
        <script src="../assets/js/wow.min.js"></script>
		<!-- plugins js -->
        <script src="../assets/js/plugins.js"></script>
		<!-- main js -->
        <script src="../assets/js/main.js"></script>
        <!-- custom js -->
        <script src="../assets/js/custom.js"></script>
        <script src="../assets/js/qrcode.js"></script>
        <script type="text/javascript">
            new QRCode(document.getElementById("qrcode"), "<?= $current["qr_code"] ?>");
        </script>
	</body>
</html>