<?php
require_once ("../lib/loader.php");
if(!isSignedIn("admin")){
    return;
}
global $activeUser;
switch (get("type")){
    case "doctor":
        $id = post("id");
        $query = new MySQLQuery();
        $query->where(["id" => $id]);
        if(!$query->select("doctor")){
            getMessage("خطأ");
            return;
        }
        if($query->rows() != 1){
            getMessage("العنصر غير مسجل");
            return;
        }
        $query->where(["id" => $id]);
        if(!$query->delete("doctor")){
            getMessage("خطأ");
            return;
        }
        break;
    case "section":
        $id = post("id");
        $query = new MySQLQuery();
        $query->where(["id" => $id]);
        if(!$query->select("section")){
            getMessage("خطأ");
            return;
        }
        if($query->rows() != 1){
            getMessage("العنصر غير مسجل");
            return;
        }
        $query->where(["id" => $id]);
        if(!$query->delete("section")){
            getMessage("خطأ");
            return;
        }
        break;
    case "level":
        $id = post("id");
        $query = new MySQLQuery();
        $query->where(["id" => $id]);
        if(!$query->select("level")){
            getMessage("خطأ");
            return;
        }
        if($query->rows() != 1){
            getMessage("العنصر غير مسجل");
            return;
        }
        $query->where(["id" => $id]);
        if(!$query->delete("level")){
            getMessage("خطأ");
            return;
        }
        break;
    case "lecture":
        $id = post("id");
        $query = new MySQLQuery();
        $query->where(["id" => $id]);
        if(!$query->select("lecture")){
            getMessage("خطأ");
            return;
        }
        if($query->rows() != 1){
            getMessage("العنصر غير مسجل");
            return;
        }
        $query->where(["id" => $id]);
        if(!$query->delete("lecture")){
            getMessage("خطأ");
            return;
        }
        break;
    case "subject":
        $id = post("id");
        $query = new MySQLQuery();
        $query->where(["id" => $id]);
        if(!$query->select("subject")){
            getMessage("خطأ");
            return;
        }
        if($query->rows() != 1){
            getMessage("العنصر غير مسجل");
            return;
        }
        $query->where(["id" => $id]);
        if(!$query->delete("subject")){
            getMessage("خطأ");
            return;
        }
        break;
    case "student":
        $id = post("id");
        $query = new MySQLQuery();
        $query->where(["id" => $id]);
        if(!$query->select("student")){
            getMessage("خطأ");
            return;
        }
        if($query->rows() != 1){
            getMessage("العنصر غير مسجل");
            return;
        }
        $query->where(["id" => $id]);
        if(!$query->delete("student")){
            getMessage("خطأ");
            return;
        }
        break;
    case "admin":
        $id = post("id");
        $query = new MySQLQuery();
        $query->where(["id" => $id]);
        if(!$query->select("admin")){
            getMessage("خطأ");
            return;
        }
        if($query->rows() != 1){
            getMessage("العنصر غير مسجل");
            return;
        }
        $query->where(["id" => $id]);
        if(!$query->delete("admin")){
            getMessage("خطأ");
            return;
        }
        break;
    default:
        getMessage(' لم يتم التحديد ' );
        return;
}

echo "<span class='data-reload'></span>";