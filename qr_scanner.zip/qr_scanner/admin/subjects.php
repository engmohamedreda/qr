<?php
require_once ("../lib/loader.php");
if(!isSignedIn("admin")){
    redirect("../");
    return;
}
global $activeUser;
?>
<!doctype html>
<html class="no-js" lang="en">
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1">

        <title> اكاديمية طيبة العليا </title>
		<!-- animate css -->
        <link rel="stylesheet" href="../assets/css/animate.css">
		<!-- jquery-ui.min css -->
        <link rel="stylesheet" href="../assets/css/jquery-ui.min.css">
		<!-- meanmenu css -->
        <link rel="stylesheet" href="../assets/css/meanmenu.min.css">
		<!-- owl.carousel css -->
        <link rel="stylesheet" href="../assets/css/owl.carousel.min.css">
        <!-- magnific popup css -->
        <link rel="stylesheet" href="../assets/css/magnific-popup.css">
        <!-- bootstrap v3.3.6 css -->
        <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
		<!-- font-awesome css -->
        <link rel="stylesheet" href="../assets/css/font-awesome.min.css">
        <!-- fancybox css -->
        <link rel="stylesheet" href="../assets/css/jquery.fancybox.css">
        <!-- flaticon css -->
        <link rel="stylesheet" href="../assets/css/flaticon.css">
        <!-- slick css -->
        <link rel="stylesheet" href="../assets/css/slick.css">

        <link rel="stylesheet" href="../assets/css/style.css">
		<!-- style css -->
		<link rel="stylesheet" href="../assets/style.css">
		<!-- responsive css -->
        <link rel="stylesheet" href="../assets/css/responsive.css">
		<!-- modernizr css -->
        <script src="../assets/js/vendor/modernizr-2.8.3.min.js"></script>
		<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
		<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
		<!--[if lt IE 9]>
		  <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
		  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
		<![endif]-->
		
	</head>
    <body>

        <!--Preloader area -->
        <div id="preloader">
            <div id="status" class="spinner">
                <div class="double-bounce1"></div>
                <div class="double-bounce2"></div>
            </div>
        </div>

        <?php
        include ("header.php");
        ?>

        <?php
            if(set("level")){
                $query = new MySQLQuery();
                $level = get("level");
                $query->where(["id" => $level]);
                $query->select("level");
                $level = $query->results()[0];
                $query->where(["id" => $level["section"]]);
                $query->select("section");
                $section = $query->results()[0];
                ?>
                <section class="trands-product section4">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                <div class="section-heading">
                                    <h2>المواد</h2>
                                </div>
                            </div>
                        </div>
                        <div class="container">
                            <div class="row wow animated fadeIn" data-wow-duration="1.5s">
                                <div class="col-xs-12">
                                    <a href="subjects.php?section=<?= $level["section"] ?>" class="btn3"> رجوع </a>
                                    <a href="add-subject.php?level=<?= get("level") ?>" class="btn3"> اضافة جديد </a>
                                    <hr>
                                </div>
                                <div class="col-xs-12">
                                    <?php
                                    $query->where(["level" => $level["id"]]);
                                    $query->select("subject");
                                    if(!$query->rows()){
                                        getMessage("لا يوجد بيانات");
                                    }else{
                                        ?>
                                        <div class="message"></div>
                                        <div class="table-responsive">
                                            <table class="table ar table-bordered">
                                                <tr>
                                                    <th>الاسم</th>
                                                    <th>المستوى</th>
                                                    <th>عرض</th>
                                                    <th>حذف</th>
                                                </tr>

                                                <?php
                                                foreach ($query->results() as $result){
                                                    ?>
                                                    <tr>
                                                        <td><?= $result["name"] ?></td>
                                                        <td><?= $section["name"] . " " . $level["name"] ?></td>
                                                        <td>
                                                            <a class="btn btn-success" href="subject.php?id=<?= $result["id"]  ?>&return=students">
                                                                <i class="fa fa-file"></i>
                                                            </a>
                                                        </td>
                                                        <td>
                                                            <a class="btn btn-danger" onclick="prepareDelete('<?= $result["id"]  ?>', 'delete.php?type=subject')" href="javascript:void(0)">
                                                                <i class="fa fa-trash"></i>
                                                            </a>
                                                        </td>
                                                    </tr>
                                                    <?php
                                                }
                                                ?>
                                            </table>
                                        </div>
                                        <?php
                                    }
                                    ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
                <?php
            }else if(set("section")){
                ?>

                <section class="trands-product section4">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                <div class="section-heading">
                                    <h2>حدد المستوى</h2>
                                </div>
                            </div>
                        </div>
                        <div class="container">
                            <div class="row wow animated fadeIn" data-wow-duration="1.5s">
                                <div class="col-xs-12">
                                    <a href="subjects.php" class="btn3"> رجوع </a>
                                    <hr>
                                </div>
                                <div class="col-xs-12">
                <?php
                $query = new MySQLQuery();
                $query->where(["section" => get("section")]);
                $query->select("level");
                if (!$query->rows()) {
                    getMessage("لا يوجد مستويات");
                }else{
                    foreach ($query->results() as $result) {
                        ?>
                            <a href="subjects.php?level=<?= $result["id"] ?>" class="btn2 full-width"><?= $result["name"] ?></a>
                            <hr>
                        <?php
                    }
                }
                ?>
                            </div>
                            </div>
                        </div>
                    </div>
                </section>
                <?php
            }else{
                ?>

                <section class="trands-product section4">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                <div class="section-heading">
                                    <h2>حدد التخصص</h2>
                                </div>
                            </div>
                        </div>
                        <div class="container">
                            <div class="row wow animated fadeIn" data-wow-duration="1.5s">
                                <div class="col-xs-12">
                                    <a href="./" class="btn3"> رجوع </a>
                                    <hr>
                                </div>
                                <div class="col-xs-12">
                                    <?php
                                    $query = new MySQLQuery();
                                    $query->select("section");
                                    if (!$query->rows()) {
                                        getMessage("لا يوجد تخصصات");
                                    }else{
                                        foreach ($query->results() as $result) {
                                            ?>
                                            <a href="subjects.php?section=<?= $result["id"] ?>" class="btn2 full-width"><?= $result["name"] ?></a>
                                            <hr>
                                            <?php
                                        }
                                    }
                                    ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
                <?php
            }
        ?>

        <!-- jquery latest version -->
        <script src="../assets/js/vendor/jquery-3.2.1.min.js"></script>
		<!-- tether js -->
		<script src="../assets/js/tether.min.js"></script>
		<!-- bootstrap js -->
        <script src="../assets/js/bootstrap.min.js"></script>
        <!-- owl.carousel js -->
        <script src="../assets/js/owl.carousel.min.js"></script>
        <!-- magnific popup js -->
        <script src="../assets/js/jquery.magnific-popup.min.js"></script>
		<!-- meanmenu js -->
        <script src="../assets/js/jquery.meanmenu.js"></script>
        <!-- jarallax js -->
        <script src="../assets/js/jarallax.min.js"></script>
		<!-- jquery-ui js -->
        <script src="../assets/js/jquery-ui.min.js"></script>
        <!-- downCount JS -->
        <script src="../assets/js/jquery.downCount.js"></script>
        <!-- slick js -->
        <script src="../assets/js/slick.min.js"></script>
        <!-- touchspin js -->
        <script src="../assets/js/jquery.bootstrap-touchspin.min.js"></script>
		<!-- fancybox js -->
        <script src="../assets/js/jquery.fancybox.min.js"></script>
        <!-- wow js -->
        <script src="../assets/js/wow.min.js"></script>
		<!-- plugins js -->
        <script src="../assets/js/plugins.js"></script>
		<!-- main js -->
        <script src="../assets/js/main.js"></script>
        <!-- custom js -->
        <script src="../assets/js/custom.js"></script>
	</body>
</html>