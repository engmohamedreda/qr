<?php
require_once ("../lib/loader.php");
if(!isSignedIn("admin")){
    redirect("../");
    return;
}

global $activeUser;

$table = "level";

$id = get("id");
$query = new MySQLQuery();

$query->where(["id" => $id]);

if(!$query->select($table)){
    redirect("./");
    return;
}
if($query->rows() != 1){
    redirect("./");
    return;
}

$current = $query->results()[0];

$query->where(["id" => $current["section"]]);
$query->select("section");
$section = $query->results()[0];

$back = "level.php?id=" . $id . "&return=". get("return");

?>
<!doctype html>
<html class="no-js" lang="en">
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1">

        <title> اكاديمية طيبة العليا </title>
		<!-- animate css -->
        <link rel="stylesheet" href="../assets/css/animate.css">
		<!-- jquery-ui.min css -->
        <link rel="stylesheet" href="../assets/css/jquery-ui.min.css">
		<!-- meanmenu css -->
        <link rel="stylesheet" href="../assets/css/meanmenu.min.css">
		<!-- owl.carousel css -->
        <link rel="stylesheet" href="../assets/css/owl.carousel.min.css">
        <!-- magnific popup css -->
        <link rel="stylesheet" href="../assets/css/magnific-popup.css">
        <!-- bootstrap v3.3.6 css -->
        <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
		<!-- font-awesome css -->
        <link rel="stylesheet" href="../assets/css/font-awesome.min.css">
        <!-- fancybox css -->
        <link rel="stylesheet" href="../assets/css/jquery.fancybox.css">
        <!-- flaticon css -->
        <link rel="stylesheet" href="../assets/css/flaticon.css">
        <!-- slick css -->
        <link rel="stylesheet" href="../assets/css/slick.css">

        <link rel="stylesheet" href="../assets/css/style.css">
		<!-- style css -->
		<link rel="stylesheet" href="../assets/style.css">
		<!-- responsive css -->
        <link rel="stylesheet" href="../assets/css/responsive.css">
		<!-- modernizr css -->
        <script src="../assets/js/vendor/modernizr-2.8.3.min.js"></script>
		<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
		<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
		<!--[if lt IE 9]>
		  <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
		  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
		<![endif]-->
		
	</head>
    <body>

        <!--Preloader area -->
        <div id="preloader">
            <div id="status" class="spinner">
                <div class="double-bounce1"></div>
                <div class="double-bounce2"></div>
            </div>
        </div>

        <?php
        include ("header.php");
        ?>

        <section class="trands-product section4">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <a href="<?= $back ?>" class="btn3"> رجوع </a>
                        <hr>
                    </div>
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <div class="section-heading">
                            <h2>تعديل بيانات مستوى</h2>
                        </div>
                    </div>
                </div>
                <div class="row wow animated fadeIn" data-wow-duration="1.5s">
                    <div class="col-xs-12">
                        <?php

                        if(set("activate")){

                            if(empty(post("name"))){
                                getMessage("البيانات غير صحيحة");
                            }else {
                                $query = new MySQLQuery();
                                $query->sql("SELECT `name` FROM {$table} WHERE `name` = ? AND `id` <> ? AND `section` = ?");

                                $query->values([post("name"), get("id"), $current["section"]]);

                                if (!$query->execute()) {
                                    getMessage("خطأ");
                                } else {
                                    if ($query->rows()) {
                                        getMessage("الاسم مسجل مسبقا");
                                    } else {
                                        $data = [
                                            "name" => post("name")
                                        ];

                                        $query->where(["id" => get("id")]);
                                        if (!$query->update($table, $data)) {
                                            getMessage("خطأ");
                                        } else {
                                            getMessage("تم التعديل", "success");
                                            $query->where(["id" => $id]);

                                            if (!$query->select($table)) {
                                                redirect("./");
                                                return;
                                            }
                                            if ($query->rows() != 1) {
                                                redirect("./");
                                                return;
                                            }

                                            $current = $query->results()[0];

                                        }

                                    }
                                }
                            }
                        }
                        ?>
                        <form method="post" action="" class="data-form">
                            <input type="text" class="form-control" name="name" placeholder="الاسم" value="<?= $current["name"] ?>">
                            <button class="btn" name="activate" type="submit">تحرير</button>
                        </form>

                    </div>
                </div>
            </div>
        </section>
        <!-- jquery latest version -->
        <script src="../assets/js/vendor/jquery-3.2.1.min.js"></script>
		<!-- tether js -->
		<script src="../assets/js/tether.min.js"></script>
		<!-- bootstrap js -->
        <script src="../assets/js/bootstrap.min.js"></script>
        <!-- owl.carousel js -->
        <script src="../assets/js/owl.carousel.min.js"></script>
        <!-- magnific popup js -->
        <script src="../assets/js/jquery.magnific-popup.min.js"></script>
		<!-- meanmenu js -->
        <script src="../assets/js/jquery.meanmenu.js"></script>
        <!-- jarallax js -->
        <script src="../assets/js/jarallax.min.js"></script>
		<!-- jquery-ui js -->
        <script src="../assets/js/jquery-ui.min.js"></script>
        <!-- downCount JS -->
        <script src="../assets/js/jquery.downCount.js"></script>
        <!-- slick js -->
        <script src="../assets/js/slick.min.js"></script>
        <!-- touchspin js -->
        <script src="../assets/js/jquery.bootstrap-touchspin.min.js"></script>
		<!-- fancybox js -->
        <script src="../assets/js/jquery.fancybox.min.js"></script>
        <!-- wow js -->
        <script src="../assets/js/wow.min.js"></script>
		<!-- plugins js -->
        <script src="../assets/js/plugins.js"></script>
		<!-- main js -->
        <script src="../assets/js/main.js"></script>
        <!-- custom js -->
        <script src="../assets/js/custom.js"></script>
	</body>
</html>