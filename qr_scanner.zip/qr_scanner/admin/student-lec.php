<?php
require_once ("../lib/loader.php");
if(!isSignedIn("admin")){
    redirect("../");
    return;
}

global $activeUser;

$table = "student";

$id = get("id");
$query = new MySQLQuery();

$query->where(["id" => $id]);

if(!$query->select($table)){
    redirect("./");
    return;
}
if($query->rows() != 1){
    redirect("./");
    return;
}

$current = $query->results()[0];

$query->where(["id" => $current["level"]]);
$query->select("level");
$level = $query->results()[0];

?>
<!doctype html>
<html class="no-js" lang="en">
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1">

        <title> اكاديمية طيبة العليا </title>
		<!-- animate css -->
        <link rel="stylesheet" href="../assets/css/animate.css">
		<!-- jquery-ui.min css -->
        <link rel="stylesheet" href="../assets/css/jquery-ui.min.css">
		<!-- meanmenu css -->
        <link rel="stylesheet" href="../assets/css/meanmenu.min.css">
		<!-- owl.carousel css -->
        <link rel="stylesheet" href="../assets/css/owl.carousel.min.css">
        <!-- magnific popup css -->
        <link rel="stylesheet" href="../assets/css/magnific-popup.css">
        <!-- bootstrap v3.3.6 css -->
        <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
		<!-- font-awesome css -->
        <link rel="stylesheet" href="../assets/css/font-awesome.min.css">
        <!-- fancybox css -->
        <link rel="stylesheet" href="../assets/css/jquery.fancybox.css">
        <!-- flaticon css -->
        <link rel="stylesheet" href="../assets/css/flaticon.css">
        <!-- slick css -->
        <link rel="stylesheet" href="../assets/css/slick.css">

        <link rel="stylesheet" href="../assets/css/style.css">
		<!-- style css -->
		<link rel="stylesheet" href="../assets/style.css">
		<!-- responsive css -->
        <link rel="stylesheet" href="../assets/css/responsive.css">
		<!-- modernizr css -->
        <script src="../assets/js/vendor/modernizr-2.8.3.min.js"></script>
		<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
		<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
		<!--[if lt IE 9]>
		  <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
		  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
		<![endif]-->
		
	</head>
    <body>

        <!--Preloader area -->
        <div id="preloader">
            <div id="status" class="spinner">
                <div class="double-bounce1"></div>
                <div class="double-bounce2"></div>
            </div>
        </div>

        <?php
        include ("header.php");
        ?>

        <?php
        if(set("subject")){
            $query->where(["id" => get("subject")]);
            $query->select("subject");
            $subject = $query->results()[0];

            $query->where(["subject" => $subject["id"]]);
            $query->select("lecture", null, ["start" => "asc"]);
            $lectures = $query->results();

            $query->sql("SELECT * FROM `student_lecture` WHERE `lecture` IN (SELECT `id` FROM `lecture` WHERE `subject` = ?)");
            $query->value($subject["id"]);
            $query->execute();
            $active = $query->results();

            $signed = [];

            foreach ($active as $ac){
                $signed[] = $ac["lecture"];
            }

            ?>
            <section class="trands-product section4">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <a href="student-lec.php?id=<?= get("id") ?>" class="btn3"> رجوع </a>
                            <hr>
                        </div>
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <div class="section-heading">
                                <h2 class="ar">
                                    نسبة حضور الطالب للمادة
                                    <?php $subject["name"] ?>
                                </h2>
                            </div>
                        </div>
                    </div>
                    <div class="row wow animated fadeIn" data-wow-duration="1.5s">
                        <div class="col-xs-12">
                            <table class="table table-striped ar">
                                <tr>
                                    <th>تاريخ</th>
                                    <th>بداية</th>
                                    <th>نهاية</th>
                                    <th>الحالة</th>
                                </tr>
                                <?php
                                foreach ($lectures as $lec){
                                    ?>
                                    <tr>
                                        <th><?= date("Y/m/d", $lec["start"]) ?></th>
                                        <th><?= date("h:i a", $lec["start"]) ?></th>
                                        <th><?= date("h:i a", $lec["end"]) ?></th>
                                        <th><?= (in_array($lec["id"], $signed) ? "<span class='color-green'>حضر</span>" : "<span class='color-red'>غاب</span>") ?></th>
                                    </tr>
                                    <?php
                                }
                                $lecC = count($lectures);
                                $sinC = count($signed);
                                ?>
                            </table>
                            <hr>
                            <table class="table table-bordered ar">
                                <tr>
                                    <th>عدد المحاضرات</th>
                                    <th>حضر</th>
                                    <th>غاب</th>
                                    <th>نسبة</th>
                                </tr>
                                <tr>
                                    <th><?= $lecC ?></th>
                                    <th><?= $sinC ?></th>
                                    <th><?= $lecC - $sinC ?></th>
                                    <th><?= ($sinC && $lecC) ? ($sinC / ($lecC/100)) : 0 ?>%</th>
                                </tr>
                            </table>
                        </div>
                    </div>
                </div>
            </section>
            <?php
        }else {
            ?>

            <section class="trands-product section4">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <div class="section-heading">
                                <h2>حدد المادة</h2>
                            </div>
                        </div>
                    </div>
                    <div class="container">
                        <div class="row wow animated fadeIn" data-wow-duration="1.5s">
                            <div class="col-xs-12">
                                <a href="student.php?id=<?= get("id") ?>" class="btn3"> رجوع </a>
                                <hr>
                            </div>
                            <div class="col-xs-12">
                                <?php
                                $query = new MySQLQuery();
                                $query->select("subject");
                                $query->sql("SELECT * FROM `subject` WHERE `id` IN (SELECT `id` FROM `student_subject` WHERE `student` = ?)");
                                $query->value($activeUser["id"]);
                                $query->execute();
                                if (!$query->rows()) {
                                    getMessage("لا يوجد مواد مسجلة");
                                }else{
                                    foreach ($query->results() as $result) {
                                        ?>
                                        <a href="student-lec.php?subject=<?= $result["id"] ?>&id=<?= get("id") ?>" class="btn2 full-width"><?= $result["name"] ?></a>
                                        <hr>
                                        <?php
                                    }
                                }
                                ?>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <?php
        }
        ?>

        <!-- jquery latest version -->
        <script src="../assets/js/vendor/jquery-3.2.1.min.js"></script>
		<!-- tether js -->
		<script src="../assets/js/tether.min.js"></script>
		<!-- bootstrap js -->
        <script src="../assets/js/bootstrap.min.js"></script>
        <!-- owl.carousel js -->
        <script src="../assets/js/owl.carousel.min.js"></script>
        <!-- magnific popup js -->
        <script src="../assets/js/jquery.magnific-popup.min.js"></script>
		<!-- meanmenu js -->
        <script src="../assets/js/jquery.meanmenu.js"></script>
        <!-- jarallax js -->
        <script src="../assets/js/jarallax.min.js"></script>
		<!-- jquery-ui js -->
        <script src="../assets/js/jquery-ui.min.js"></script>
        <!-- downCount JS -->
        <script src="../assets/js/jquery.downCount.js"></script>
        <!-- slick js -->
        <script src="../assets/js/slick.min.js"></script>
        <!-- touchspin js -->
        <script src="../assets/js/jquery.bootstrap-touchspin.min.js"></script>
		<!-- fancybox js -->
        <script src="../assets/js/jquery.fancybox.min.js"></script>
        <!-- wow js -->
        <script src="../assets/js/wow.min.js"></script>
		<!-- plugins js -->
        <script src="../assets/js/plugins.js"></script>
		<!-- main js -->
        <script src="../assets/js/main.js"></script>
        <!-- custom js -->
        <script src="../assets/js/custom.js"></script>
        <script>
            $(".check-link").click(function (){
                let checkbox = $(this).find("input[type=checkbox]");
                if(checkbox.is(":checked")){
                    checkbox.attr("checked", false);
                    $(this).removeClass("active");
                }else{
                    checkbox.attr("checked", true);
                    $(this).addClass("active");
                }
            });
        </script>
	</body>
</html>