<header>
    <div class="topbar">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-3 col-xs-12 hidden-sm hidden-xs">
                    <div class="top-l-social">
                        <ul class="list-inline">
                            <li><a href="#"><i class="fa fa-facebook"></i> </a></li>
                            <li><a href="#"><i class="fa fa-twitter"></i> </a></li>
                            <li><a href="#"><i class="fa fa-instagram"></i> </a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-9 col-xs-12">
                    <div class="top-linked text-right">
                        <ul class="list-inline">
                            <li><a href="#"><i class="fa fa-envelope"></i><span>info@thebes-academy.edu</span></a></li>
                            <li><a href="#"><i class="fa fa-mobile-phone"></i><span>0222222222222</span></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="header-middel">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-7 col-xs-8">
                    <div class="logo">
                        <a href="./"><img class="top-logo" src="../assets/images/logo.png" alt="اكاديمية طيبة العليا"/></a>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-5 col-xs-4">
                    <div class="cart-btn text-right">
                        <a href="out.php" class="cart-btns" title="cart">
                            <strong>تسجيل خروج</strong>
                            <span class="icon"><i class="fa fa-sign-out"></i></span>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="main-menu">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="menu-list">
                        <nav>
                            <ul class="list-inline">
                                <li class="lists-menus">
                                </li>
                            </ul>
                        </nav>
                    </div>
                    <!-- Mobile Menu  Start -->
                    <div class="mobilemenu1">
                        <div class="mobile-menu visible-sm visible-xs">
                            <button class="btn btn-menu mobile-menu-alt"><i class="fa fa-bars"></i></button>
                        </div>
                    </div>
                    <!-- Mobile Menu End -->
                </div>
            </div>
        </div>
        <div class="cat-ser">
            <div class="search-box">
            </div>
        </div>
    </div>
    <!--Offset wrapper end here-->
    <div class="offset-overlay"></div>
    <div class="offset-area">
        <!--Cart area start-->
        <div class="offset-cart-area offset-body">
            <div class="offset-heading text-right"><h3>القائمة الرئيسية</h3><i class="close-offset flaticon-letter-x"></i></div>
            <div class="cart-list">
                <nav class="actions-nav">
                    <ul class="actions-list">
                        <li><a href="./">البيانات الشخصية</a></li>
                        <li><a ref="javascript:void(0)" onclick="WebSystem.scan()">تسجيل الحضور</a></li>
                        <li><a href="out.php">تسجيل خروج</a></li>
                        <li><a href="javascript:void(0)" onclick="WebSystem.close()">إيقاف التطبيق</a></li>
                    </ul>
                </nav>
            </div>
        </div>
        <!--Cart area end-->
    </div>
</header>