<?php
require_once ("../lib/loader.php");
unset_cookies("student");
redirect("../");